<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Teacher Home</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
		<?php include"navbar.php";?><br>
	
			<div id="section">
				<?php include"sidebar.php";?><br>
					<h3 class="text">Welcome <?php echo $_SESSION["TNAME"]; ?></h3><br><hr><br>
				<div class="content">
				
					<h3>Add Profile</h3><br>
					<div class="lbox1">
					<?php
						if(isset($_POST["submit"]))
						{
							$target="staff/";
							$target_file=$target.basename($_FILES["img"]["name"]);
							
							if(move_uploaded_file($_FILES['img']['tmp_name'],$target_file))
							{
								$sql="update staff set LNAME='{$_POST["lname"]}',GENDER='{$_POST["gender"]}',DOB='{$_POST["dob"]}',PNO='{$_POST["pno"]}',MAIL='{$_POST["mail"]}',PADDR='{$_POST["addr"]}',QUAL='{$_POST["qual"]}',CASTE='{$_POST["caste"]}',NATION='{$_POST["nation"]}',IMG='{$target_file}'where TID={$_SESSION["TID"]}";
								$db->query($sql);
								echo "<div class='success'>Insert Success</div>";
							}
							
						}
					
					
					?>
					
					
					
					
						
					<form  enctype="multipart/form-data" role="form"  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
							<label>  First Name</label><br>
							<input type="text" required class="input3" name="fname"><br><br>
							<label>  Last Name</label><br>
							<input type="text" required class="input3" name="lname"><br><br>
							<label>  Gender</label><br>
							
							<select name="gender"  required class="input3">
									<option value="">Select</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
							</select><br><br>
							<label>DOB</label><br>
							<input type="date" required class="input3" name="dob"><br><br>

							<label>  Phone No</label><br>
							<input type="text" maxlength="10" required class="input3" name="pno"><br><br>
							<label>  E - Mail</label><br>
							<input type="email"  class="input3" required name="mail"><br><br>
							<label>  Address</label><br>
							<textarea rows="5" name="addr"></textarea><br><br>
							<label>  Qualification</label><br>
							<input type="text" required class="input3" name="qual"><br><br>
							<label>  Caste</label><br>
							<select name="caste"  required class="input3">
									<option value="">Select</option>
									<option value="GM">GM</option>
									<option value="OBC">OBC</option>
									<option value="SC/ST">SC/ST</option>
									<option value="Other">Other</option>
							</select><br><br>
							<label>  Nationality</label><br>
							<input type="text" required class="input3" name="nation"><br><br>
							<label> Image</label><br>
							<input type="file"  class="input3" required name="img"><br><br>
						<button type="submit" class="btn" name="submit">Add Profile Details</button>
						</form>
					</div>
					
					
					
					
					
				</div>
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>