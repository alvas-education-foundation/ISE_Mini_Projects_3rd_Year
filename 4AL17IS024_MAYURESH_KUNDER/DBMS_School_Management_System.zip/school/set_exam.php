<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Set Exam</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
			<?php include"navbar.php";?>
			
			
			<div id="section5">
			
					<?php include"sidebar.php";?><br>
				
				
				<div class="content6">
					<?php
						if(isset($_POST["submit"]))
						{
							
							
							$sq="insert into exam(ENAME,ETYPE,EDATE,SESSION,CLASS,SUB) values ('{$_POST["ename"]}','{$_POST["etype"]}','{$_POST["date"]}','{$_POST["ses"]}','{$_POST["cla"]}','{$_POST["sub"]}')";
							if($db->query($sq))
							{
								echo "<div class='success'>Insert Success</div>";
							}
							else
							{
								echo "<div class='error'>Insert Failed</div>";
							}
						}
					?>
			
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					
					<div class="lbox">
						<label> Exam Name</label><br>
							<input type="text" class="input6" name="ename"><br><br>
						<label> Select Term</label><br>
							<select name="etype" required class="input6">
						       <option value="">Select</option>
						       <option value="I-Term">I-Term</option>
						       <option value="II-Term">II-Term</option>
						       <option value="III-Term">III-Term</option>
							</select>
					<br><br>
					
					<label> Exam Date</label><br>
					<input type="date" class="input6" name="date"><br><br>
					
				</div>
				
				<div class="rbox">
					<label>Session</label><br>
						<select name="ses" required class="input6">
							<option value="">Select</option>
							<option value="FN">FN</option>
							<option value="AN">AN</option>
						</select>
					<br><br>
					
					
					<label>Class</label><br>
					<select name="cla" required class="input6">
						<?php
							$sl="select DISTINCT(CNAME) from class";
							$r=$db->query($sl);
							if($r->num_rows>0)
							{
								echo 	"<option value=''>Select</option>";
								while($ro=$r->fetch_assoc())
								{
									echo "<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
								}
								
							}
						?>	
						
					</select>
					
					<br><br>
					
					
					<label>Subject</label><br>
					<select name="sub" required class="input6">
						<?php
							$s="select * from sub";
							$re=$db->query($s);
							if($re->num_rows>0)
							{
								echo "<option value=''>Select</option>";
								while($r=$re->fetch_assoc())
								{
									echo "<option value='{$r["SNAME"]}'>{$r["SNAME"]}</option>";
								}
							}
						?>
						
					</select>
					<br><br><br>
				</div>
					<button type="submit" class="but13" name="submit">Add Exam</button>
				</form>
				
				
				</div>
				
				
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>