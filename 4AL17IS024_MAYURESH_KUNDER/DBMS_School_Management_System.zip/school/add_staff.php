<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add Staff</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	
	<body class="back">
			<?php include"navbar.php";?>
			
			
			<div id="section2">
				
				<?php include"sidebar.php";?><br>
				<div class="content3">
						
					<?php
						if(isset($_POST["submit"]))
						{
							$sq="insert into staff(TID,TNAME,TPASS) values('{$_POST["sid"]}','{$_POST["sname"]}','{$_POST["spass"]}')";
							if($db->query($sq))
							{
								echo "<div class='success'>Insert Success..</div>";
							}
							else
							{
								echo "<div class='error'>Insert Failed..</div>";
							}
							
						}
						
					?>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
						 <label>Staff ID</label><br>
					     <input type="text" name="sid" required class="input3"><br><br>
					     <label>Staff Name</label><br>
					     <input type="text" name="sname" required class="input3">
					     <br><br>
					     <label>Password</label><br>
					     <input type="text" name="spass" required class="input3">
					     <br>
					     <button type="submit" class="but1" name="submit">Add Staff Details</button>
					</form>
				
				
				</div>
				
				
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>