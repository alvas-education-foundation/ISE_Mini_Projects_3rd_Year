<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add Marks</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
		<?php include"navbar.php";?>
	
			<div id="section12">
				<?php include"sidebar.php";?><br>
				<div class="content13">
				
					
					 <?php
						if(isset($_GET["err"]))
						{
							echo "<div class='error'>{$_GET["err"]}</div>";
						}
					?>
					<form  method="get" action="mark.php">
					<div class="lbox44">	
					
						<label>Enter Roll No</label><br>
						<input type="text" class="input10" name="rno"><br><br>
					</select>
					
					</div>
					<br>
					<button type="submit" class="but44" name="view"> Go</button>
				
					</form>
			</div>
				</div>
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>