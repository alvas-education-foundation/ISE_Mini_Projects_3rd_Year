<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add Subject</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
				<?php include"navbar.php";?>
								
			<div id="section1">
					<?php include"sidebar.php";?><br>
					<div class="content2">
					
						
						<?php
							if(isset($_POST["submit"]))
							{
								$sq="insert into sub(SID,SNAME,SCLASS) values ('{$_POST["sid"]}','{$_POST["sname"]}','{$_POST["sclass"]}')";
								if($db->query($sq))
								{
									echo "<div class='success'>Insert Success..</div>";
								}
								else
								{
									echo "<div class='error'>Insert Failed..</div>";
								}
							}
						?>
						
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
						   <label>Subject Code</label><br>
						   <input type="text" name="sid" required class="input"><br><br>
						   <label>Subject Name</label><br>
						   <input type="text" name="sname" required class="input"><br><br>
						   <label>Class</label><br>
						   <input type="text" name="sclass" required class="input"><br>
						   <button type="submit" class="btn" name="submit">Add Subject</button>
						</form>
				
				
					</div>
				
				
				<div class="tbox1" >
					<center><h3 style="margin-top:30px;"> Subject Details</h3></center><br>
					<?php
						if(isset($_GET["mes"]))
						{
							echo"<div class='error'>{$_GET["mes"]}</div>";	
						}
					
					?>
					<table class="t2">
						<tr>
							<thead>
							<th>S.No</th>
							<th>Subject Code</th>
							<th>Subject Name</th>
							<th>Class</th>
							<th>Delete</th></thead>
						</tr>
						<?php
							$s="select * from sub";
							$res=$db->query($s);
							if($res->num_rows>0)
							{
								$i=0;
								while($r=$res->fetch_assoc())
								{
									$i++;
									echo "
										<tr>
										<td>{$i}</td>
										<td>{$r["SID"]}</td>
										<td>{$r["SNAME"]}</td>
										<td>{$r["SCLASS"]}</td>
										<td><a href='sub_delete.php?id={$r["SID"]}' class='btnr'>Delete</a></td>
										</tr>
									
									";
									
								}
								
							}
							else
							{
								echo "No Record Found";
							}
						?>
						
					</table>
				</div>
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>