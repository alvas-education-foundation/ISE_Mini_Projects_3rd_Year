<div class="navbar">

			<ul class="list">
				<b style="color:white;float:left;line-height:60px;margin-left:35px;font-family:Courier New;font-size: 24px;">
				School Management System</b>
			<?php
				if(isset($_SESSION["AID"]))
				{
					echo'
				
						<li style="font-size: 20px"><a href="add_class.php">Admin Home</a></li>
				<li style="font-size: 20px"><a href="change_pass.php">Settings</a></li>
				<li style="font-size: 20px"><a href="logout.php">Logout</a></li>
					';
				}
				elseif(isset($_SESSION["TID"]))
				{
					echo'
				
						<li style="font-size: 20px"><a href="profile.php">Faculty Home</a></li>
				<li style="font-size: 20px"><a href="teacher_change_pass.php">Settings</a></li>
				<li style="font-size: 20px"><a href="logout.php">Logout</a></li>
					';
				}
				else{
					echo'
					
					<li style="font-size: 20px"><a href="admin_login.php">Principal</a></li>
				<li style="font-size: 20px"><a href="teacher_login.php">Faculty</a></li>
				<li style="font-size: 20px"><a href="/school/web/index.php">Home</a></li>
				';
				}
			?>
				
			</ul>
		</div>
		