<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Meta tags -->
	<title>mySchool</title>
	
	
	<!-- stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/lightbox.css">

	<!-- scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/numscroller-1.0.js"></script>

	
	<!-- google fonts -->
	
</head>
<body>
	<div class="w3lshome" id="home">
		<div class="navbar navbar-default navbar-fixed-top w3ls-navbar">
			<div class= "container brand1">
				<a href="#" class="navbar-brand w3-logo">mySchool</a>
				
				<button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<!-- navbar collapse -->
				<div class="collapse navbar-collapse navHeaderCollapse">
					<ul class="nav navbar-nav navbar-right w3ls-nav">
						<li><a class="scroll" href="#home">Home</a></li>
						<li><a class="scroll" href="#about">About</a></li>
						<li><a class="scroll" href="#team">Team</a></li>
						<li><a class="scroll" href="#gallery">Gallery</a></li>
						<li><a class="nav-link" href="/school/admin_login.php">Principal</a></li>
						<li><a class="nav-link" href="/school/teacher_login.php">Faculty</a></li>
						<li><a class="scroll" href="#contact">Contact</a></li>
					</ul>
				</div>
			</div>
		</div>
		<!-- navbar end-->
		<div class="w3-banner-heading">
			<h1>Welcome To The Unique Education Place</h1>
			<P>Beyond Excellence Skills</p> 
		</div>
	</div><!-- banner ends -->

	<!-- About Section -->
	<div class="w3ls-about" id="about">
		<div class="container w3about">
			<div class="about-txt">
				<h2>Education</h2>
				<br>
				<p>Education system forms the backbone of every nation. And hence it is important to provide a strong
						educational foundation to the young generation to ensure the development of open-minded global
 						citizens securing the future for everyone. Advanced technology available today can play a crucial role in streamlining education-related processes to promote solidarity among students, teachers, parents and the school staff.</p>
 						<br>
 						<h2>Our Mission</h2>
 						<p>Our school's mission is to learn leadership, the common core, and relationships for life and provide a safe, disciplined learning environment that empowers all students to develop their full potential. We feel strongly about helping to build leaders that have the ability to succeed in whatever endeavor they undertake.Our students understand the "Win, win" philosophy and use it in their daily life.Last but just as importantly, setting examples for our students of meaningful and lasting relationships will go with them throughout their lifetime.</p><br>
			</div>
			<div class="about-img">
				<img src="images/banner3.jpg" class="img-responsive" alt="about image" />
			</div>
		</div>
	</div>
	<!-- //About Section -->
	<!-- team-inner-page -->
	<div class="team" id="team">
		<div class="container">
			<h3 class="center">Our Team</h3>
			<div class="w3l_team_grids">
				<div class="col-md-3 col-sm-6 col-xs-6 w3l_team_grid">
					<div class="view view-second">
						<img src="images/dk1.jpg" alt=" " class="img-responsive" />
						
						
					</div>
					<h4>Dikshit Kotian</h4>
					<h5 style="font-color: #0d0c0a;">Founder</h5>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6 w3l_team_grid">
					<div class="view view-second">
						<img src="images/img1.jpg" alt=" " class="img-responsive" />
						
					</div>
					<h4>Mayuresh Kunder</h4>
					<h5 style="font-color: #0d0c0a;">Trustee</h5>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6 w3l_team_grid">
					<div class="view view-second">
						<img src="images/img2.jpg" alt=" " class="img-responsive" />
						
					</div>
					<h4>Mahima</h4>
					<h5 style="font-color: #0d0c0a;">Principal</h5>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6 w3l_team_grid">
					<div class="view view-second">
						<img src="images/img3.jpg" alt=" " class="img-responsive" />
						
					</div>
					<h4>Anju</h4>
					<h5 style="font-color: #0d0c0a;">Dean</h5>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //team-inner-page -->

	<!-- Our Services -->
	
	<!-- Our Services -->
	<!-- our stats -->
	
	<!-- //our stats -->
	<!-- gallery -->
	<div class="gallery" id="gallery">
		<h3 class="center">Our Gallery</h3>
		<div class="container">
			<div class="gallery-grids">
					<div class="col-md-4 col-sm-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/1.jpg" data-lightbox="example-set">
									<img src="images/1.jpg" alt="" />
									
								</a>
							</figure>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/2.jpg" data-lightbox="example-set">
									<img src="images/2.jpg" alt="" />
									
								</a>
							</figure>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/3.jpg" data-lightbox="example-set">
									<img src="images/3.jpg" alt="" />	
								</a>
							</figure>
						</div>
					</div>
					
					<div class="col-md-4 col-sm-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/6.jpg" data-lightbox="example-set">
									<img src="images/6.jpg" alt="" />
									
								</a>
							</figure>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/7.jpg" data-lightbox="example-set">
									<img src="images/b4.jpg" alt="" />
									
								</a>
							</figure>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/8.jpg" data-lightbox="example-set">
									<img src="images/4.jpg" alt="" />
										
								</a>
							</figure>
						</div>
					</div>
					
					
					<div class="clearfix"> </div>
					<script src="js/lightbox-plus-jquery.min.js"> </script>
			</div>
		</div>
	</div>
	<!-- //gallery -->

	<!-- our blog -->
	
	<!-- our blog -->
	<!-- Map -->
	
	<!-- //Map -->
	<!-- cotact form -->
	
	<!-- //cotact form -->
	<!-- Contact Section --><br><br>
	<div class="contact w3ls-contact" id="contact">
		<div class="container w3-contact">
			<div class="list1">
			<ul class="contact-list">
				<li class="heading"> Contact Us</li>
				<li style="font-size: 18px">Mijar,Moodbidri,DK-574225</li>
				<li style="font-size: 18px">Phone:852-957-1879</li>
			</ul>
			
			<ul class="contact-hrs">
				<li class="heading">Our Timings</li>
				<li style="font-size: 18px">Monday - Saturday</li>
				<li style="font-size: 18px">09:00 AM - 05:00 PM</li>
			</ul>
			</div>
			<div class="list2">
			<ul class="social-links">
				<li class="heading">Follow Us </li>
				<li style="font-size: 18px"><a href="facebook.com">Facebook</a></li>
				<li style="font-size: 18px"><a href="twitter.com">Twitter</a></li>
				<li style="font-size: 18px"><a href="pinterest.com">Pinterest</a></li>
				<li style="font-size: 18px"><a href="plus.google.com">Google+ </a></li>
			</ul>
			
			
			</div>
		</div>
		
	</div>
	<!-- //Contact Section -->
		<!-- //footer -->
	<!-- copyright -->
	<div class="agileits-w3layouts">
		<div class="container">
			<h4 style="color: white">School: A Tradition of Pride</h4>
		</div>
	</div>
	<!-- //copyright -->
	<script src="js/SmoothScroll.min.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- scrolling script -->
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
	</script> 
	<!-- //scrolling script -->
</body>
</html>