<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Teacher Home</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
		<?php include"navbar.php";?>
			<div id="section">
				<?php include"sidebar.php";?><br>
					<h3 class="text">Welcome <?php echo $_SESSION["TNAME"]; ?></h3><br><hr>
				
					
					
					
					
					<div class="rbox1">
					
						<table class="t5">
							<tr><th>Profile</th><td colspan="2"><img src="<?php echo $row["IMG"] ?>" height="100" width="100" alt="upload Pending" style="border-radius: 50%"></td></tr>
							<tr><th>First Name </th> <td><?php echo $row["TNAME"] ?> </td></tr>
							<tr><th>Last Name </th> <td><?php echo $row["LNAME"] ?> </td></tr>
							<tr><th>Gender </th> <td><?php echo $row["GENDER"] ?> </td></tr>
							<tr><th>DOB </th> <td><?php echo $row["DOB"] ?> </td></tr>
							<tr><th>Qualification </th> <td><?php echo $row["QUAL"] ?>  </td></tr>
							<tr><th>Salary </th> <td> <?php echo $row["SAL"] ?>  </td></tr>
							<tr><th>Phone No </th> <td> <?php echo $row["PNO"] ?> </td></tr>
							<tr><th>E - Mail </th> <td> <?php echo $row["MAIL"] ?> </td></tr>
							<tr><th>Address </th> <td> <?php echo $row["PADDR"] ?> </td></tr>
							<tr><th>Caste </th> <td><?php echo $row["CASTE"] ?> </td></tr>
							<tr><th>Nationality </th> <td><?php echo $row["NATION"] ?> </td></tr>
							
							
							<br>
							
						</table><br>
						<a href="teacher_home.php" class="but123">Edit Profile</a>
						<br><br><br><br><br><br>
					</div>
				</div>
		
	
				<?php include"footer.php";?>
	</body>
</html>