<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add Student</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
		<?php include"navbar.php";?>
		
			<div id="section9">
				<?php include"sidebar.php";?><br>
				<div class="content10">
				
					<?php
						if(isset($_POST["submit"]))
						{
							
							$target="student/";
							$target_file=$target.basename($_FILES["img"]["name"]);
							if(move_uploaded_file($_FILES['img']['tmp_name'],$target_file))
							{
								$sq="insert into student(RNO,NAME,FNAME,DOB,GEN,PHO,MAIL,ADDR,SCLASS,SSEC,SIMG,TID) values('{$_POST["rno"]}','{$_POST["name"]}','{$_POST["fname"]}','{$_POST["dob"]}','{$_POST["gen"]}','{$_POST["pho"]}','{$_POST["email"]}','{$_POST["addr"]}','{$_POST["cla"]}','{$_POST["sec"]}','{$target_file}','{$_SESSION["TID"]}')";
								
								if($db->query($sq))
								{
									echo "<div class='success'>Insert Success</div>";
								}
								else
								{
									echo "<div class='error'>Insert Failed</div>";
								}
							}
							
						}
					
					
					
					
					
					
					?>
			
				<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>">
				<div class="lbox22">
					<label> ID</label><br>
						<?php
							$no="S101";
							$sql="select * from student order by ID desc limit 1";
							$res=$db->query($sql);
							if($res->num_rows>0)
							{
								$row1=$res->fetch_assoc();
								$no=substr($row1["RNO"],1,strlen($row1["RNO"]));
								$no++;
								$no="S".$no;
							}
						
						
						
						?>
					<input type="text" class="input3" name="rno" value="<?php echo $no;?>" readonly  ><br><br>
					<label> Student Name</label><br>
					<input type="text" class="input3" name="name"><br><br>
					<label> Father Name</label><br>
					<input type="text" class="input3" name="fname"><br><br>
				
						
					<label>  Date of Birth</label><br>
					<input type="date" class="input3" name="dob"><br><br>
					<label>Gender</label><br>
					<select name="gen" required class="input3">
							<option value="">Select</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
					</select><br><br>
					
					<label> Phone No</label><br>
					<input type="text" class="input3" maxlength="10" name="pho">
				</div>
				
				<div class="rbox22">
				
				<label> Parent's Mail Id</label><br>
					<input type="email" class="input3" name="email"><br><br>
					
					<label>  Address</label><br>
					<textarea rows="5" name="addr"></textarea><br><br>
				
					<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
							 $sl="SELECT DISTINCT(CNAME) FROM class";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
										}
									}
						?>
					
					</select>
					<br><br>
						<label>Section</label><br>
						<select name="sec" required class="input3">
						<?php 
							 $sl="SELECT DISTINCT(CSEC) FROM class";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["CSEC"]}'>{$ro["CSEC"]}</option>";
										}
									}
						?>
					
					</select><br></br>
					<label> Image</label><br>
					<input type="file"  class="input3" required name="img"><br><br><br>			
			
				</div>
				<button type="submit" class="but23" name="submit">Add Student</button>
					
				</form>
				
				
				</div>
				
				
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>