<div class="sidebar">
<h3 class="text">Dashboard</h3>
<ul class="s">
<?php
	if(isset($_SESSION["AID"]))
	{
	
		echo'
			
			<li class="li"><a href="add_class.php"> Classes</a></li>
			<li class="li"><a href="add_sub.php"> Subjects</a></li>

			<li class="li"><a href="add_staff.php">Add Staff</a></li>
			<li class="li"><a href="view_staff.php">View Staff</a></li>
			<li class="li"><a href="student.php"> View Student</a></li>
			<li class="li"><a href="set_exam.php">Set Exam</a></li>
			<li class="li"><a href="view_exam.php">View Exam</a></li>
			<li class="li"><a href="logout.php">Logout</a></li>
		';
	
	
	}
	else{
		echo'
			<li class="li"><a href="profile.php">My Profile</a></li>
			<li class="li"><a href="handle_class.php"> Handled Class</a></li>
			<li class="li"><a href="add_stud.php">Add Student</a></li>
			<li class="li"><a href="view_stud_teach.php"> View Student</a></li>

			<li class="li"><a href="tech_view_exam.php">View Exam</a></li>
			<li class="li"><a href="add_mark.php">Add Marks</a></li>
			<li class="li"><a href="view_mark.php">View Marks</a></li>
			<li class="li"><a href="attendance.php">Update Attendance</a></li>
			<li class="li"><a href="view_attendance.php">View Attendance</a></li>
			<li class="li"><a href="logout.php">Logout</a></li>

		
		';
	}


?>
	

</ul>

</div>