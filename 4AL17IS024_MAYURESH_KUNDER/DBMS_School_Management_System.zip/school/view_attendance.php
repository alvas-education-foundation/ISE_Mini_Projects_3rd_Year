<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>View Attendance</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	
	<body class="back">
			<?php include"navbar.php";?>
			
			
			<div id="section16">
				
				<?php include"sidebar.php";?><br>
				<div class="content17">
					
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
						 <label>Date</label><br>
					     <input type="date" name="date" required class="input14"><br><br>
					     <label>Student ID</label><br>
					     <input type="text" name="sid" required class="input14">
					     <br>
					     <button type="submit" class="but88" name="submit">View</button>
					</form>
				
				
				</div>
				<div class="Output1">
						<?php
						if(isset($_POST["submit"]))
							{
								echo "<h3>Attendance</h3><br>";
								$sql="select * from attendance where date='{$_POST["date"]}' and sid='{$_POST["sid"]}'";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
									echo'
									<table class="t10">
										<tr><thead>
										<th>S.No</th>
											<th>Subject</th>
											<th>Status</th></thead>
										</tr>
									';
									$i=0;
									while($r=$re->fetch_assoc())
									{
										$i++;
										echo "
											<tr>
												<td>{$i}</td>
												<td>{$r["subject"]}</td>
												<td>{$r["status"]}</td>
											</tr>
										
										
										
										
										";
									}
								}
								else
								{
									echo "No Record Found";
								}
								echo "</table>";
								
							}
						?>
					<br>
					<br>
					
					</div>

					<div class="Output1">
						<?php
						if(isset($_POST["submit"]))
							{
								echo "<h3>Overall</h3><br>";
								$sql="select * from attendance where sid='{$_POST["sid"]}'";
								$re=$db->query($sql);
								$r1=mysqli_num_rows($re);
								$sql1="select * from attendance where sid='{$_POST["sid"]}' and status='Present'";
								$re1=$db->query($sql1);
								$r11=mysqli_num_rows($re1);
								
									echo'
									<table class="t10">
										<tr>
										<th>Classes Conducted</th>
											<th>Classes Attended</th>
										</tr>
									';
									
										echo "
											<tr>
												
												<td>{$r1}</td>
												<td>{$r11}</td>
											</tr>
											";
									
								
								echo "</table>";
							}
						?>
					
					
					</div>
				
				
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>