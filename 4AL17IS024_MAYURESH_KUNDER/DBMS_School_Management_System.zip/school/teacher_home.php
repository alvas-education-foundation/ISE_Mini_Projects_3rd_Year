<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Teacher Home</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body class="back">
		<?php include"navbar.php";?>
	
			<div id="section7">
				<?php include"sidebar.php";?><br>
				<div class="content8">
				
					
					<div class="lbox11">
					<?php
						if(isset($_POST["submit"]))
						{
							$target="staff/";
							$target_file=$target.basename($_FILES["img"]["name"]);
							
							if(move_uploaded_file($_FILES['img']['tmp_name'],$target_file))
							{
								$sql="update staff set TNAME='{$_POST["fname"]}',LNAME='{$_POST["lname"]}',GENDER='{$_POST["gender"]}',DOB='{$_POST["dob"]}',PNO='{$_POST["pno"]}',MAIL='{$_POST["mail"]}',PADDR='{$_POST["addr"]}',QUAL='{$_POST["qual"]}',CASTE='{$_POST["caste"]}',NATION='{$_POST["nation"]}',SAL='{$_POST["salary"]}',IMG='{$target_file}'where TID={$_SESSION["TID"]}";
								$db->query($sql);
								echo "<div class='success'>Insert Success</div>";
							}
							
						}
					
					
					?>
					
					
					
					
						
					<form  enctype="multipart/form-data" role="form"  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
							<label>  First Name</label><br>
							<input type="text" required class="input7" name="fname"><br><br>
							<label>  Last Name</label><br>
							<input type="text" required class="input7" name="lname"><br><br>
							<label>  Gender</label><br>
							
							<select name="gender"  required class="input7">
									<option value="">Select</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
							</select><br><br>
							<label>DOB</label><br>
							<input type="date" required class="input7" name="dob"><br><br>

							<label>  Phone No</label><br>
							<input type="text" maxlength="10" required class="input7" name="pno"><br><br>
							<label>  E - Mail</label><br>
							<input type="email"  class="input7" required name="mail"><br><br>
							<label>  Address</label><br>
							<textarea rows="5" name="addr" class="input7"></textarea><br><br>
							<label>  Qualification</label><br>
							<input type="text" required class="input7" name="qual"><br><br>
							<label>  Caste</label><br>
							<select name="caste"  required class="input7">
									<option value="">Select</option>
									<option value="GM">GM</option>
									<option value="OBC">OBC</option>
									<option value="SC/ST">SC/ST</option>
									<option value="Other">Other</option>
							</select><br><br>
							<label>  Nationality</label><br>
							<input type="text" required class="input7" name="nation"><br><br>
							<label>  Salary</label><br>
							<input type="text" required class="input7" name="salary"><br><br>
							<label> Image</label><br>
							<input type="file"  class="input7" required name="img"><br>
						<button type="submit" class="but1234" name="submit">Edit Profile</button>
						<br><br><br><br><br>
						</form>
					</div>
					
				</div>
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>