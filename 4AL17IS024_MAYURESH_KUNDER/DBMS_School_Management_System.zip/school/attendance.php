<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Attendance</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	
	<body class="back">
			<?php include"navbar.php";?>
			
			
			<div id="section15">
				
				<?php include"sidebar.php";?><br>
				<div class="content16">
					
						
					<?php
						if(isset($_POST["submit"]))
						{
							$sq="insert into attendance(date,sid,subject,status) values('{$_POST["date"]}','{$_POST["sid"]}','{$_POST["sub"]}','{$_POST["status"]}')";
							if($db->query($sq))
							{
								echo "<div class='success'>Insert Success..</div>";
							}
							else
							{
								echo "<div class='error'>Insert Failed..</div>";
							}
							
						}
						
					?>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
						 <label>Date</label><br>
					     <input type="date" name="date" required class="input13"><br><br>
					     <label>Student ID</label><br>
					     <input type="text" name="sid" required class="input13">
					     <br><br>
					     <label>Subject</label><br>
					     <input type="text" name="sub" required class="input13">
					     <br><br>
					     <b><p style="color: #d60845">Status</p></b>
  						 <input type="radio" name="status" value="Present"><p class="i1" style="color:white"> Present</p>
 						 <input type="radio" name="status" value="Absent"><p class="i1" style="color:white"> Absent</p><br>
					     <button type="submit" class="but77" name="submit">Update</button>
					</form>
				
				
				</div>
				
				
			</div>
	
				<?php include"footer.php";?>
	</body>
</html>